# Telegram Bot (Render + GitHub)

1. Create the bot with @BotFather and copy the token.
2. Push this folder to a GitHub repo.
3. On Render: New > Blueprint (or Web Service) > select the repo.
4. In Render > Environment, add `BOT_TOKEN` = your token. Never commit it.
5. Deploy, then send /start to your bot.

Local test: copy `.env.example` to `.env`, fill in the token, then `npm install && npm start`.
