require("dotenv").config();
const express = require("express");
const { Telegraf } = require("telegraf");

const BOT_TOKEN = process.env.BOT_TOKEN;
const PORT = process.env.PORT || 3000;
// Render sets RENDER_EXTERNAL_URL automatically for web services
const BASE_URL = process.env.RENDER_EXTERNAL_URL || process.env.WEBHOOK_URL;
const SECRET = process.env.WEBHOOK_SECRET || "dev-secret";
const WEBHOOK_PATH = "/telegram/webhook";

if (!BOT_TOKEN) {
  console.error("Missing BOT_TOKEN environment variable");
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);

// ---------- Bot logic (edit this part) ----------
bot.start((ctx) =>
  ctx.reply(`Hello ${ctx.from.first_name}! 👋 Your bot is running on Render.`)
);
bot.help((ctx) => ctx.reply("Commands:\n/start - greet\n/help - this message\n/ping - test"));
bot.command("ping", (ctx) => ctx.reply("pong 🏓"));
bot.on("text", (ctx) => ctx.reply(`You said: ${ctx.message.text}`));
bot.catch((err) => console.error("Bot error:", err));
// -------------------------------------------------

const app = express();
app.use(express.json());

app.get("/", (_req, res) => res.send("Telegram bot is alive ✅"));

app.post(WEBHOOK_PATH, (req, res) => {
  if (req.get("X-Telegram-Bot-Api-Secret-Token") !== SECRET) {
    return res.sendStatus(401);
  }
  bot.handleUpdate(req.body, res).catch((e) => {
    console.error(e);
    if (!res.headersSent) res.sendStatus(500);
  });
});

app.listen(PORT, async () => {
  console.log(`Server listening on port ${PORT}`);
  try {
    if (BASE_URL) {
      await bot.telegram.setWebhook(`${BASE_URL}${WEBHOOK_PATH}`, {
        secret_token: SECRET,
      });
      console.log(`Webhook set: ${BASE_URL}${WEBHOOK_PATH}`);
    } else {
      // Local development: use long polling
      await bot.telegram.deleteWebhook();
      bot.launch();
      console.log("No public URL found, running in polling mode");
    }
  } catch (err) {
    console.error("Failed to connect to Telegram. Check BOT_TOKEN:", err.message);
  }
});

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
